package com.zd.retrofit_rxjava2.shopcar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.zd.retrofit_rxjava2.MainActivity;
import com.zd.retrofit_rxjava2.R;
import com.zd.retrofit_rxjava2.shopcar.adapter.ShopCarAdapter;
import com.zd.retrofit_rxjava2.shopcar.presenter.ShopCarPresenter;

import base.BaseAcitivity;
import bean.ShopCarBean;
import contract.IShopCarContract;
/**
 *@describe(描述)：ShopCarActivity
 *@data（日期）: 2019/10/15
 *@time（时间）: 16:47
 *@author（作者）: fanyanlong
 **/


public class ShopCarActivity extends BaseAcitivity implements IShopCarContract.Iview {
    public static final String TAG="ShopCarActivity";
    private ShopCarPresenter shopCarPresenter;
    private String sid;
    private RecyclerView recyclerView;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_shop_car;
    }

    @Override
    protected void initdata() {
        sid = getIntent().getStringExtra("sid");
        shopCarPresenter = new ShopCarPresenter();
        if (shopCarPresenter!=null){
            shopCarPresenter.attachView(ShopCarActivity.this);
            shopCarPresenter.getPresenter("10218",sid);
        }


    }

    @Override
    protected void initview() {
        recyclerView = findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }


    @Override
    public void onShopCarSuccess(Object data) {
        //类型转换
        ShopCarBean shopCarBean= (ShopCarBean) data;
        Log.d(TAG, "onShopCarSuccess: "+shopCarBean.getMessage());
        recyclerView.setAdapter(new ShopCarAdapter(ShopCarActivity.this,shopCarBean));
    }

    @Override
    public void onShopCarFailure(String e) {

    }
}

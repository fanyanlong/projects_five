package com.zd.retrofit_rxjava2.shopcar.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.yanzhenjie.recyclerview.SwipeRecyclerView;
import com.zd.retrofit_rxjava2.R;

import java.util.List;

import bean.ShopCarBean;

/**
 *@describe(描述)：ShopCarAdapter
 *@data（日期）: 2019/10/16
 *@time（时间）: 10:39
 *@author（作者）: fanyanlong
 **/
public class ShopCarAdapter  extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context  context;
    private ShopCarBean shopCarBean;
    private SwipeRecyclerView mSwipeRecyclerView;
    private ShopCarBean.ResultBean resultBean;
    private ShopCarItemAdapter shopCarItemAdapter;

    public ShopCarAdapter(Context context, ShopCarBean shopCarBean) {
        this.context=context;
        this.shopCarBean=shopCarBean;
    }

    @SuppressLint("WrongConstant")
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
         //一级（商家）
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_shopcar, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        //二级（商品）
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        resultBean = shopCarBean.getResult().get(position);
        if (holder instanceof MyViewHolder){
            ((MyViewHolder) holder).textView.setText(resultBean.getCategoryName());
            shopCarItemAdapter = new ShopCarItemAdapter(context, resultBean);
            mSwipeRecyclerView.setAdapter(shopCarItemAdapter);
        }


    }

    @Override
    public int getItemCount() {
        return shopCarBean.getResult().size();
    }

    class  MyViewHolder extends  RecyclerView.ViewHolder{

        private final TextView textView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.shop_car_name);
            mSwipeRecyclerView= itemView.findViewById(R.id.recycler);

            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            mSwipeRecyclerView.setLayoutManager(linearLayoutManager);


        }
    }
}

package com.zd.retrofit_rxjava2.shopcar.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.zd.retrofit_rxjava2.R;
import com.zd.retrofit_rxjava2.view.ShopAddView;

import java.util.List;

import bean.ShopCarBean;

/**
 *@describe(描述)：ShopCarItemAdapter
 *@data（日期）: 2019/10/16
 *@time（时间）: 11:28
 *@author（作者）: fanyanlong
 **/
public class ShopCarItemAdapter extends RecyclerView.Adapter <RecyclerView.ViewHolder>{
    public static final String TAG="ShopCarItemAdapter";
    private Context context;
    private MyViewHolder myViewHolder;
    ShopCarBean.ResultBean resultBean;
    private ShopCarBean.ResultBean.ShoppingCartListBean shoppingCartListBean;

    public ShopCarItemAdapter(Context context, ShopCarBean.ResultBean  resultBean ) {
        this.context=context;
        this.resultBean=resultBean;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
           //加载子布局
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_shopcaritem, parent, false);
        myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof  MyViewHolder){
            shoppingCartListBean = resultBean.getShoppingCartList().get(position);
            ((MyViewHolder) holder).mTitletextView.setText(shoppingCartListBean.getCommodityName());
            Log.d(TAG, "onBindViewHolder: "+shoppingCartListBean.getCommodityName());
            ((MyViewHolder) holder).mPricetextview.setText(shoppingCartListBean.getPrice());
            Glide.with(context).load(shoppingCartListBean.getPic()).into(((MyViewHolder) holder).mImageview);
            ((MyViewHolder) holder).mShopviewadd.setCount(Integer.valueOf(shoppingCartListBean.getCount()));
            ((MyViewHolder) holder).mCricle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    shoppingCartListBean.setSelected(!shoppingCartListBean.isSelected());
                    notifyItemChanged(position);
                }
            });
            //判断商品是否选中状态
            if (shoppingCartListBean.isSelected()) {
                ((MyViewHolder) holder).mCricle.setImageResource(R.mipmap.shop_car_all);
            } else {
                ((MyViewHolder) holder).mCricle.setImageResource(R.drawable.shop_car_cricle);
            }


            ((MyViewHolder) holder).mShopviewadd.setOnNumListener(new ShopAddView.OnNumListener() {
                @Override
                public void count(int count) {
                    Log.d(TAG, "count: "+count);
                }
            });


        }

    }

    @Override
    public int getItemCount() {
        return resultBean.getShoppingCartList().size();
    }

    class  MyViewHolder extends  RecyclerView.ViewHolder {

        private final TextView mTitletextView,mPricetextview;
        private final ShopAddView mShopviewadd;
        private final ImageView mImageview,mCricle;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            mTitletextView = itemView.findViewById(R.id.shop_car_title);
            mPricetextview = itemView.findViewById(R.id.shop_car_price);
            mImageview = itemView.findViewById(R.id.shop_car_image);
            mCricle = itemView.findViewById(R.id.iv_cricle);
            mShopviewadd = itemView.findViewById(R.id.shop_add);



        }

    }
}
